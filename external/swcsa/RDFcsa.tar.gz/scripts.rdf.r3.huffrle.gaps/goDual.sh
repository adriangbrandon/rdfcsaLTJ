../BUILDALLDUALwcsa_PSI_R3H_GAPS ./texts/dbpedia.hdt indexes/dbpedia4   "sPsi=4;  nsHuff=16; psiSF=1"

