
../BUILDINTINDEXwcsa ./indexes/cnlong "sPsi=16; nsHuff=16;psiSF=4"
