../BUILDUNCOMPRESSwcsa ./indexes/jamendo jamendo.txt

cmp jamendo.txt.source  ./indexes/jamendo.sorted


