mkdir indexes
#zcat ./texts/cnlong.txt.gz | ../BUILDSORTwcsa stdin ./indexes/cnlong

../BUILDSORTwcsa ./texts/jamendo.hdt ./indexes/jamendo
