#!/bin/bash

cp ../joins/big/outSamplingJoin1_1_nodir.txt_big.txt joinsOO1_big.txt
cp ../joins/big/outSamplingJoin1_2_nodir.txt_big.txt joinsOO2_big.txt
cp ../joins/big/outSamplingJoin1_3_nodir.txt_big.txt joinsOO3_big.txt
cp ../joins/big/outSamplingJoin1_4_nodir.txt_big.txt joinsOO4_big.txt
cp ../joins/big/outSamplingJoin1_5_nodir.txt_big.txt joinsOO5_big.txt
cp ../joins/big/outSamplingJoin1_6_nodir.txt_big.txt joinsOO6_big.txt
cp ../joins/big/outSamplingJoin1_7_nodir.txt_big.txt joinsOO7_big.txt
cp ../joins/big/outSamplingJoin1_8_nodir.txt_big.txt joinsOO8_big.txt

cp ../joins/small/outSamplingJoin1_1_nodir.txt_small.txt joinsOO1_small.txt
cp ../joins/small/outSamplingJoin1_2_nodir.txt_small.txt joinsOO2_small.txt
cp ../joins/small/outSamplingJoin1_3_nodir.txt_small.txt joinsOO3_small.txt
cp ../joins/small/outSamplingJoin1_4_nodir.txt_small.txt joinsOO4_small.txt
cp ../joins/small/outSamplingJoin1_5_nodir.txt_small.txt joinsOO5_small.txt
cp ../joins/small/outSamplingJoin1_6_nodir.txt_small.txt joinsOO6_small.txt
cp ../joins/small/outSamplingJoin1_7_nodir.txt_small.txt joinsOO7_small.txt
cp ../joins/small/outSamplingJoin1_8_nodir.txt_small.txt joinsOO8_small.txt
