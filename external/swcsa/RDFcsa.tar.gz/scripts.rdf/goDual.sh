../BUILDALLDUALwcsa_PSI_R3H_GAPS ./texts/jamendo.hdt ./indexes/jamendo              "sPsi=16; nsHuff=16;psiSF=4"
