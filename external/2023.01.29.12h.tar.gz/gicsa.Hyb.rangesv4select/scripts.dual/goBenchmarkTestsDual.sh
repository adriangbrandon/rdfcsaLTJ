# ../benchmarkTest indexes/dbpedia16 1
# ../benchmarkTest indexes/dbpedia16 2
# ../benchmarkTest indexes/dbpedia16 3
# ../benchmarkTest indexes/dbpedia16 4
# ../benchmarkTest indexes/dbpedia16 5
# ../benchmarkTest indexes/dbpedia16 6
# ../benchmarkTest indexes/dbpedia16 7


../benchmarkTestDualwcsa indexes/wiki1 1
../benchmarkTestDualwcsa indexes/wiki1 2
../benchmarkTestDualwcsa indexes/wiki1 3
../benchmarkTestDualwcsa indexes/wiki1 4
../benchmarkTestDualwcsa indexes/wiki1 5
../benchmarkTestDualwcsa indexes/wiki1 6
../benchmarkTestDualwcsa indexes/wiki1 7

