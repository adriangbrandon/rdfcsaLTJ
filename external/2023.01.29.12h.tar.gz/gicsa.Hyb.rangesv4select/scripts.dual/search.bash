#!/bin/bash
bash goSimplesDBLP
bash goSimplesDBpedia
bash goSimplesGeonames
bash goSimplesJamendo
