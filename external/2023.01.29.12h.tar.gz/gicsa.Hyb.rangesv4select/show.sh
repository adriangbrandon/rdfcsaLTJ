
echo "vvv ........................................................."
cat scripts.rdf.r3h/VVV.dat scripts.rdf.r3h.gaps/VVV.dat scripts.rdf.r3h.uint32/VVV.dat

echo "SPO ........................................................."
cat scripts.rdf.r3h/spo.dat scripts.rdf.r3h.gaps/spo.dat scripts.rdf.r3h.uint32/spo.dat

echo "SP? ........................................................."
cat scripts.rdf.r3h/spV.dat scripts.rdf.r3h.gaps/spV.dat scripts.rdf.r3h.uint32/spV.dat

echo "?p? ........................................................."
cat scripts.rdf.r3h/VpV.dat scripts.rdf.r3h.gaps/VpV.dat scripts.rdf.r3h.uint32/VpV.dat

echo "S?O ........................................................."
cat scripts.rdf.r3h/sVo.dat scripts.rdf.r3h.gaps/sVo.dat scripts.rdf.r3h.uint32/sVo.dat

echo "S?? ........................................................."
cat scripts.rdf.r3h/sVV.dat scripts.rdf.r3h.gaps/sVV.dat scripts.rdf.r3h.uint32/sVV.dat

echo "?PO ........................................................."
cat scripts.rdf.r3h/Vpo.dat scripts.rdf.r3h.gaps/Vpo.dat scripts.rdf.r3h.uint32/Vpo.dat

echo "??O ........................................................."
cat scripts.rdf.r3h/VVo.dat scripts.rdf.r3h.gaps/VVo.dat scripts.rdf.r3h.uint32/VVo.dat
