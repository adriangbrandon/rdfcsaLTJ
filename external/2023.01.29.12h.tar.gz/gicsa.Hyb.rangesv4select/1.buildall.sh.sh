  #cd scripts.rdf.huffrle                    ; sh goBuildAllDbpedia.sh ; cd ..
  #cd scripts.plain                          ; sh goBuildAllDbpedia.sh ; cd ..

  #cd scripts.rdf.r3.huffrle                 ; sh goBuildAllDbpedia.sh ; cd ..
  #cd scripts.rdf.r3.huffrle_bitmapRGK       ; sh goBuildAllDbpedia.sh ; cd ..
cd scripts.rdf.r3.huffrle.gaps            ; sh goBuildAllDbpedia.sh ; cd ..
  #cd scripts.rdf.r3.huffrle.gaps_bitmapRGK  ; sh goBuildAllDbpedia.sh ; cd ..

#cd scripts.rdf.r3h                        ; sh goBuildAllDbpedia.sh ; cd ..
#cd scripts.rdf.r3h_bitmapRGK              ; sh goBuildAllDbpedia.sh ; cd ..
cd scripts.rdf.r3h.gaps                   ; sh goBuildAllDbpedia.sh ; cd ..
#cd scripts.rdf.r3h.uint32                 ; sh goBuildAllDbpedia.sh ; cd ..
