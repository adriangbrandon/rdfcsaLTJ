#!/bin/bash

cp ../joins/big/outSamplingJoin2_1_nodir.txt_big.txt joinsSS1_big.txt
cp ../joins/big/outSamplingJoin2_2_nodir.txt_big.txt joinsSS2_big.txt
cp ../joins/big/outSamplingJoin2_3_nodir.txt_big.txt joinsSS3_big.txt
cp ../joins/big/outSamplingJoin2_4_nodir.txt_big.txt joinsSS4_big.txt
cp ../joins/big/outSamplingJoin2_5_nodir.txt_big.txt joinsSS5_big.txt
cp ../joins/big/outSamplingJoin2_6_nodir.txt_big.txt joinsSS6_big.txt
cp ../joins/big/outSamplingJoin2_7_nodir.txt_big.txt joinsSS7_big.txt
cp ../joins/big/outSamplingJoin2_8_nodir.txt_big.txt joinsSS8_big.txt

cp ../joins/small/outSamplingJoin2_1_nodir.txt_small.txt joinsSS1_small.txt
cp ../joins/small/outSamplingJoin2_2_nodir.txt_small.txt joinsSS2_small.txt
cp ../joins/small/outSamplingJoin2_3_nodir.txt_small.txt joinsSS3_small.txt
cp ../joins/small/outSamplingJoin2_4_nodir.txt_small.txt joinsSS4_small.txt
cp ../joins/small/outSamplingJoin2_5_nodir.txt_small.txt joinsSS5_small.txt
cp ../joins/small/outSamplingJoin2_6_nodir.txt_small.txt joinsSS6_small.txt
cp ../joins/small/outSamplingJoin2_7_nodir.txt_small.txt joinsSS7_small.txt
cp ../joins/small/outSamplingJoin2_8_nodir.txt_small.txt joinsSS8_small.txt
