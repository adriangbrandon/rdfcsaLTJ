
sh compile.sh

sh 0.prepare.sh

sleep 5
sh 1.buildall.sh.sh

sleep 5
sh 2.searchall.sh

sh cleanall.sh
