../benchmarkTest indexes/dbpedia16 1
../benchmarkTest indexes/dbpedia16 2
../benchmarkTest indexes/dbpedia16 3
../benchmarkTest indexes/dbpedia16 4
../benchmarkTest indexes/dbpedia16 5
../benchmarkTest indexes/dbpedia16 6
../benchmarkTest indexes/dbpedia16 7


