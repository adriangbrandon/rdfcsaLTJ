sh goBuildAllDBLP.sh
sh goBuildAllDbpedia.sh
sh goBuildAllGeonames.sh
sh goBuildAllJamendo.sh
