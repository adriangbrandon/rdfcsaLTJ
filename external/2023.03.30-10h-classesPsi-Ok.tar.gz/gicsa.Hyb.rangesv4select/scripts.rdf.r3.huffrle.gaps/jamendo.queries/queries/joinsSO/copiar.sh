#!/bin/bash

cp ../joins/big/outSamplingJoin3_1_nodir.txt_big.txt joinsSO1_big.txt
cp ../joins/big/outSamplingJoin3_2_nodir.txt_big.txt joinsSO2_big.txt
cp ../joins/big/outSamplingJoin3_3_nodir.txt_big.txt joinsSO3_big.txt
cp ../joins/big/outSamplingJoin3_4_nodir.txt_big.txt joinsSO4_big.txt
cp ../joins/big/outSamplingJoin3_5_nodir.txt_big.txt joinsSO5_big.txt
cp ../joins/big/outSamplingJoin3_6_nodir.txt_big.txt joinsSO6_big.txt
cp ../joins/big/outSamplingJoin3_7_nodir.txt_big.txt joinsSO7_big.txt
cp ../joins/big/outSamplingJoin3_8_nodir.txt_big.txt joinsSO8_big.txt

cp ../joins/small/outSamplingJoin3_1_nodir.txt_small.txt joinsSO1_small.txt
cp ../joins/small/outSamplingJoin3_2_nodir.txt_small.txt joinsSO2_small.txt
cp ../joins/small/outSamplingJoin3_3_nodir.txt_small.txt joinsSO3_small.txt
cp ../joins/small/outSamplingJoin3_4_nodir.txt_small.txt joinsSO4_small.txt
cp ../joins/small/outSamplingJoin3_5_nodir.txt_small.txt joinsSO5_small.txt
cp ../joins/small/outSamplingJoin3_6_nodir.txt_small.txt joinsSO6_small.txt
cp ../joins/small/outSamplingJoin3_7_nodir.txt_small.txt joinsSO7_small.txt
cp ../joins/small/outSamplingJoin3_8_nodir.txt_small.txt joinsSO8_small.txt
