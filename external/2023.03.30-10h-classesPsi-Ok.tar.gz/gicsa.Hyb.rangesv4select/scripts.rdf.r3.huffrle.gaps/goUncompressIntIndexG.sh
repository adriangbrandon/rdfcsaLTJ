
../BUILDUNCOMPRESSINTINDEXwcsa ./indexes/jamendo  jamendo.se
cmp jamendo.se.source indexes/jamendo.se 
