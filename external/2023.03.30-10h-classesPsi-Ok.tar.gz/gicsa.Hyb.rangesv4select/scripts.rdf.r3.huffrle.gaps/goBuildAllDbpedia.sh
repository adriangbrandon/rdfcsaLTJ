ln -s ../../sandra texts

#./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia2   "sPsi=2;  nsHuff=16; psiSF=1"
#./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia4   "sPsi=4;  nsHuff=16; psiSF=1"
#./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia8   "sPsi=8;  nsHuff=16; psiSF=1"
#./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia16  "sPsi=16;  nsHuff=16; psiSF=1"
#./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia32  "sPsi=32;  nsHuff=16; psiSF=1"
#./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia64  "sPsi=64;  nsHuff=16; psiSF=1" 
#./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia512  "sPsi=512;  nsHuff=16; psiSF=1" 


./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia4   "sPsi=4;  nsHuff=16; psiSF=1"
./BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia32  "sPsi=32;  nsHuff=16; psiSF=1"
