rm -f benchmark BUILDALLwcsa

ln -s ../benchmarkwcsa_PSI_R3H_GAPS benchmark
ln -s ../BUILDALLwcsa_PSI_R3H_GAPS  BUILDALLwcsa

rm -f indexes
ln -s ../indexes/r3/gaps indexes
