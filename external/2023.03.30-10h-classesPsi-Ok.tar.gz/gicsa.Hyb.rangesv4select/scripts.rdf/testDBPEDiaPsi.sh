../BUILDUNCOMPRESSINTINDEXwcsa ./indexes/dbpedia16 indexes/dbpedia16.se2
cmp indexes/dbpedia16.se indexes/dbpedia16.se2.source 
