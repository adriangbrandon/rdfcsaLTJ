mkdir indexes
#zcat ./texts/cnlong.txt.gz | ../BUILDPARSERwcsa stdin ./indexes/cnlong

../BUILDPARSERwcsa ./texts/cnlong.txt ./indexes/cnlong
