ln -s ../../sandra texts

../BUILDALLwcsa ./texts/dbpedia.hdt indexes/dbpedia8  "sPsi=8;  nsHuff=16; psiSF=4"

