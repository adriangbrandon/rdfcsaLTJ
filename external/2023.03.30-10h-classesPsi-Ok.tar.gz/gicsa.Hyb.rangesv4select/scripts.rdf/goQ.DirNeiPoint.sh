../benchmark indexes/cnlong ./queries/cnlong/1000queries-dirnei-point.txt 0 490
